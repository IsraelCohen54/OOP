import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Final four.
 */
public class Level4 implements LevelInformation {
    private Sprite background;
    private List<Block> blocks;
    private List<Velocity> initialBallVelocities;
    /**
     * construct level 4.
     * creating background and blocks.
     * Initializing balls' speeds.
     */
    public Level4() {
        this.background = new Background4();
        this.blocks = new ArrayList<>();
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 140), 50, 20);
            block.setBlockHealth(1); //TODO check if I want it to have 2 lives
            block.setBlockColor(Color.YELLOW);
            this.blocks.add(block);
        }
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 160), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.RED);
            this.blocks.add(block);
        }
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 180), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.YELLOW);
            this.blocks.add(block);
        }
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 200), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.GREEN);
            this.blocks.add(block);
        }
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 220), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.WHITE);
            this.blocks.add(block);
        }
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 240), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.CYAN);
            this.blocks.add(block);
        }
        for (int i = 0; i < 15; ++i) {
            Block block = new Block(new Point(725 - i * 50, 260), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.pink);
            this.blocks.add(block);
        }
        this.initialBallVelocities = new ArrayList<>();
        this.initialBallVelocities.add(new Velocity(5, -5));
        this.initialBallVelocities.add(new Velocity(0, -5));
        this.initialBallVelocities.add(new Velocity(-5, -5));
    }
    /**
     * Number of balls int.
     *
     * @return the int
     */
    @Override
    public int numberOfBalls() {
        return this.initialBallVelocities.size();
}

    /**
     * Initial ball velocities list.
     *
     * @return the list
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        return this.initialBallVelocities;
    }

    /**
     * Paddle speed int.
     *
     * @return the int
     */
    @Override
    public int paddleSpeed() {
        return 7;
    }

    /**
     * Paddle width int.
     *
     * @return the int
     */
    @Override
    public int paddleWidth() {
        return 60;
    }

    /**
     * Level name string.
     *
     * @return the string
     */
    @Override
    public String levelName() {
        return "Final Four";
    }

    /**
     * Gets background.
     *
     * @return the background
     */
    @Override
    public Sprite getBackground() {
        return this.background;
    }

    /**
     * Blocks list.
     *
     * @return the list
     */
    @Override
    public List<Block> blocks() {
        return this.blocks;
    }

    /**
     * Number of blocks to remove int.
     *
     * @return the int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return this.blocks.size();
    }
}
