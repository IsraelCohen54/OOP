import biuoop.GUI;

import java.util.ArrayList;
import java.util.List;

/**
 * Ass3Game class.
 * the main class of this assignment.
 */

public class Ass6Game {
    /**
     * this is the main method.
     * @param args this array stores the user's input.
     */
    public static void main(String[] args) {
        GUI gui = new GUI("Arkanoid", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui, 60);
        List<LevelInformation> levels = new ArrayList<LevelInformation>();
        for (int i = 0; i < args.length; i++) {
            try {
                switch (Integer.parseInt(args[i])) {
                    case 1:
                        levels.add(new Level1());
                        break;
                    case 2:
                        levels.add(new Level2());
                        break;
                    case 3:
                        levels.add(new Level3());
                        break;
                    case 4:
                        levels.add(new Level4());
                        break;
                    default:
                        break;
                }
            } catch (NumberFormatException e) {
                continue;
            }
        }
        GameFlow game = new GameFlow(ar, gui.getKeyboardSensor(), 7, 800, 600);
        game.runLevels(levels);
        gui.close();
    }

/*public class Ass5Game {

    public static void main(String[] args) {
        Level1 firststage = new Level1();
        GameLevel game = new GameLevel(firststage);
        game.initialize();
        game.playOneTurn();
    }*/
}