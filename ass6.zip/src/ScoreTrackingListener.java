/**
 * This class represents a score tracking listener object.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;
    /**
     * construct a score tracking listener from a score counter object.
     *
     * @param scoreCounter the given score counter object.
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * updates game score according to what is asked.
     *
     * @param beingHit the block.
     * @param hitter   the ball.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        if (beingHit.getBlockHealth() == 0) {
            this.currentScore.increase(10);
        }
        if (beingHit.getBlockHealth() > 0) {
            this.currentScore.increase(5);
        }
    }
}