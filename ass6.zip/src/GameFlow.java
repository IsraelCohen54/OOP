import java.util.List;

import biuoop.KeyboardSensor;

/**
 * this class manages the game handling.
 */
public class GameFlow {
    private KeyboardSensor keyboardSensor;
    private AnimationRunner animationRunner;
    private int horizontalBound;
    private int verticalBound;
    private Counter lives;
    private Counter score;
    private boolean win;

    /**
     * this method construct a gameFlow object.
     *
     * @param ar              an animation runner connected to a gui object.
     * @param ks              a keyboard sensor connected to a gui object.
     * @param numOfLives      the initial number of lives in this game.
     * @param horizontalBound the width of that gui.
     * @param verticalBound   the height of that gui.
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, int numOfLives,
                    int horizontalBound, int verticalBound) {
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.horizontalBound = horizontalBound;
        this.verticalBound = verticalBound;
        this.lives = new Counter(numOfLives);
        this.score = new Counter(0);
        this.win = true;
    }

    /**
     * this method gets a list of levelInformation objects
     * and runs the appropriate levels.
     *
     * @param levelsList the given list.
     */
    public void runLevels(List<LevelInformation> levelsList) {
        for (LevelInformation levelInfo : levelsList) {
            GameLevel level = new GameLevel(levelInfo, this.keyboardSensor, this.animationRunner, this.score,
                    this.lives);
            level.initialize();
            LivesIndicator li = new LivesIndicator(this.lives);
            ScoreIndicator si = new ScoreIndicator(this.score);
            LevelNameIndicator lni =
                    new LevelNameIndicator(levelInfo.levelName());
            level.addSprite(li);
            level.addSprite(si);
            level.addSprite(lni);
            while (this.lives.getValue() > 0) {
                level.playOneTurn();
                if (level.ifItsAWin()) {
                    this.score.increase(100);
                    break;
                } else {
                    this.lives.decrease(1);
                }
            }
            if (this.lives.getValue() == 0) {
                this.win = false;
                break;
            }
        }
        this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, "space",
                new EndScreen(this.score, this.win)));
    }
}