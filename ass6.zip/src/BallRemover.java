/**
 * this class represents a ball remover.
 */
public class BallRemover implements HitListener {
    private GameLevel game;
    private Counter rmvNumOfBallsFromTheGame;

    /**
     * construct a ball remover from a game and and counter of balls.
     *
     * @param game                     a game to remove balls from.
     * @param rmvNumOfBallsFromTheGame the num of balls we wish to remove.
     */
    public BallRemover(GameLevel game, Counter rmvNumOfBallsFromTheGame) {
        this.game = game;
        this.rmvNumOfBallsFromTheGame = rmvNumOfBallsFromTheGame;
    }

    /**
     * when a ball is hitting the death region, it removes the ball from the game and updates the number of
     * balls that left in the game.
     *
     * @param beingHit the block at the death region.
     * @param hitter   the hitter - the ball.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(this.game);
        this.rmvNumOfBallsFromTheGame.decrease(1);
    }
}