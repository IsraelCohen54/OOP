import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import biuoop.KeyboardSensor;

import java.awt.Color;
import java.util.List;

/**
 * The type Game.
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private Sleeper sleeper;
    private GUI gui;
    private int xHorizonBound = 800;
    private int yVerticalBound = 600;
    private Counter lives;
    private Counter score;
    private Counter remainingBlocks;
    private Counter remainingBalls;
    private AnimationRunner runner;
    private boolean running;
    private Paddle pad;
    private KeyboardSensor keyboard;
    private List<Block> blocks;
    private List<Velocity> initialBallsVelocity;

    /**
     * constructor.
     *
     * @param level           the level
     * @param keyboard        the keyboard
     * @param animationRunner the animation runner
     * @param score           the score
     * @param lives           the lives
     */
    public GameLevel(LevelInformation level, KeyboardSensor keyboard, AnimationRunner animationRunner,
                     Counter score, Counter lives) {
        this.sprites = new SpriteCollection();
        this.sprites.addSprite(level.getBackground());
        this.environment = new GameEnvironment();
        this.sleeper = new Sleeper();
        //   this.gui = new GUI("Game", xHorizonBound, yVerticalBound);
        this.remainingBlocks = new Counter(level.numberOfBlocksToRemove());
        this.remainingBalls = new Counter(0); //TODO check if add to constructor or switch-case
        this.score = new Counter(0);
        this.lives = new Counter(4); //TODO check for problems with life
        this.lives = lives;
        this.running = true;
        // this.keyboard = gui.getKeyboardSensor();
        this.blocks = level.blocks();
        this.initialBallsVelocity = level.initialBallVelocities();
        this.pad = new Paddle(xHorizonBound, yVerticalBound, keyboard);
        this.score = score; //TODO check for score problems
        this.keyboard = keyboard;
        this.runner = animationRunner;
        this.running = true;

    }

    /**
     * Add collidable.
     *
     * @param c the c
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * Add sprite.
     *
     * @param s the s
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * Remove collidable.
     *
     * @param c - removing collidable.
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * Remove sprite.
     *
     * @param s - removing sprite.
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSpr(s);
    }

    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * and adding them to the game.
     */
    public void initialize() {
        /*this.runner = new AnimationRunner(this.gui, 60);
        ScoreIndicator theScore = new ScoreIndicator(this.score);
        LivesIndicator theLives = new LivesIndicator(this.lives);
        this.addSprite(theLives);
        this.addSprite(theScore);*/

        // add bounding window blocks to the game
        Block upWinBound = new Block(new Point(0, 15), xHorizonBound, 20);
        Block leftWinBound = new Block(new Point(0, 0), 20, yVerticalBound);
        Block lowWinBound = new Block(new Point(0, yVerticalBound - 1), xHorizonBound, 20);
        Block rightWinBound = new Block(new Point(xHorizonBound - 20, 0), 20, yVerticalBound + 20);
        upWinBound.setBlockColor(Color.CYAN);
        upWinBound.addBlockToTheGame(this);
        leftWinBound.setBlockColor(Color.CYAN);
        leftWinBound.addBlockToTheGame(this);
        lowWinBound.addBlockToTheGame(this);
        BlockRemover blockRmv = new BlockRemover(this, this.remainingBlocks);
        BallRemover ballRmv = new BallRemover(this, this.remainingBalls);
        lowWinBound.addHitListener(ballRmv);
        lowWinBound.setBlockColor(Color.CYAN);
        rightWinBound.addBlockToTheGame(this);
        rightWinBound.setBlockColor(Color.CYAN);

        ScoreTrackingListener theNewScore = new ScoreTrackingListener(this.score);
//        LiveIndicator
        for (Block i : this.blocks) {
            i.addBlockToTheGame(this);
            i.addHitListener(blockRmv);
            i.addHitListener(theNewScore);
        }
        /*for (int i = 0; i < 6; i++) {
            Color c = new Color(40, 30 * i, i * 35);
            for (int j = 0; j < 12 - i; j++) {
                int hit = 1;
                if (i == 0) {
                    hit = 2;
                }
                int blockHeight = 30;
                int blockWidth = 55;
                Point p = new Point(xHorizonBound - 20 - (j + 1) * blockWidth,
                        120 + blockHeight * i);
                Block b = new Block(p, blockWidth, blockHeight);
                b.setBlockHealth(hit);
                b.setBlockColor(c);
                b.addHitListener(theNewScore);
                b.addHitListener(blockRmv);
                this.remainingBlocks.increase(1);
                b.addBlockToTheGame(this);
            }
        }*/
    }

    /**
     * Run.
     */
   /* public void run() {
        this.removeSprite(this.pad);
        if (this.lives.getValue() != 0) {
            playOneTurn();
        } else {
            gui.close();
        }
    }*/

    /**
     * Do one frame.
     *
     * @param d the d
     */
    public void doOneFrame(DrawSurface d) {
        if (this.remainingBalls.getValue() == 0) {
            this.running = false;
        }
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();

        if (this.remainingBlocks.getValue() == 0) {
            this.score.increase(100);
            this.running = false;
            //gui.close();
        }
        if (this.keyboard.isPressed("p")) {
            this.runner.run(new KeyPressStoppableAnimation(this.keyboard,
                    "space", new PauseScreen(/*this.keyboard*/)));
        }
        if (this.remainingBalls.getValue() == 0) { //TODO CHECK if  only :"this.running = false;" needed
            this.running = false;
            /*this.lives.decrease(1);
            this.remainingBalls.setValue(2);
            this.removeSprite(pad);
            this.removeCollidable(pad);
            run();*/
        }
    }

    /**
     * this method tells if the player win the game.
     *
     * @return true if the player wins, false otherwise.
     */
    public boolean ifItsAWin() {
        return this.remainingBlocks.getValue() == 0;
    }

    /**
     * the methods create the balls.
     */
    private void createBallsOnTopOfPaddle() {
        this.pad = new Paddle(xHorizonBound, yVerticalBound, this.keyboard);
        this.pad.addPadToGame(this);
        for (Velocity i : this.initialBallsVelocity) {
            Ball ball = new Ball(new Point(this.xHorizonBound / 2,
                    this.yVerticalBound - 26), 5, Color.LIGHT_GRAY, this.environment);
            ball.setVelocity(i);
            this.remainingBalls.increase(1);
            this.addSprite(ball);
        }
    }


        /*Ball ballOne = new Ball(xHorizonBound / 2, 250 + yVerticalBound
                / 2, 5, Color.BLACK, xHorizonBound, yVerticalBound);
        Ball ballTwo = new Ball(xHorizonBound / 2, 250 + yVerticalBound
                / 2, 5, Color.BLACK, xHorizonBound, yVerticalBound);
        ballOne.setVelocity(Velocity.fromAngleAndSpeed(179.5, 4));
        ballTwo.setVelocity(Velocity.fromAngleAndSpeed(180.5, 4));
        ballOne.setGameEnvironment(this.environment);
        ballTwo.setGameEnvironment(this.environment);
        this.addSprite(ballOne);
        this.addSprite(ballTwo);
        } */


    /**
     * check if the program should be stopped.
     *
     * @return running.
     */
    public boolean shouldStop() {
        return !this.running;
    }

    /**
     * OneTurnOf the game.
     */
// Run the game -- start the animation loop.
    public void playOneTurn() {
        this.createBallsOnTopOfPaddle();
        this.runner.run(new CountdownAnimation(2, 3, this.sprites)); //TODO check if sprites work
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.runner.run(this);
        this.removeSprite(this.pad); //TODO check if needed
        this.removeCollidable(this.pad);
        return;
    }
}