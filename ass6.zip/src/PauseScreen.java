import biuoop.DrawSurface;
//import biuoop.KeyboardSensor;

/**
 * The type Pause screen.
 */
public class PauseScreen implements Animation {

    // private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * Instantiates a false Pause screen.
     */
    public PauseScreen(/*KeyboardSensor k*/) {
        //this.keyboard = k;
        this.stop = false;
    }

    /**
     * Do one frame.
     *
     * @param d the d
     */
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
        /*if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.stop = true;
        }*/
    }

    /**
     * @return value of boolean.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}