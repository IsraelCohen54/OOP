import java.awt.Color;
import biuoop.DrawSurface;

/**
 * This class represents a lives indicator object.
 */
public class LivesIndicator implements Sprite {
    private Counter lives;
    private Rectangle rectangle;

    /**
     * constructing the lives indicator from a given life counter.
     *
     * @param lives the given lives counter.
     */
    public LivesIndicator(Counter lives) {
        this.lives = lives;
        this.rectangle = new Rectangle(new Point(0, 0), 200, 15);
    }
    /**
     * Drawing the lives indicator on at the DrawSurface.
     * @param surface = the DrawSurface we draw upon.
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(Color.LIGHT_GRAY);
        surface.fillRectangle((int) this.rectangle.getUpperLeft().getx(), (int) this.rectangle.getUpperLeft().gety(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
        surface.setColor(Color.BLACK);
        surface.drawText((int) (this.rectangle.getUpperLeft().getx() + this.rectangle.getWidth() / 2 - 20),
                (int) (this.rectangle.getUpperLeft().gety() + this.rectangle.getHeight() / 2 + 5),
                "Lives: " + Integer.toString(this.lives.getValue()), 13);
    }
    /**
     * notifying the lives indicator that a time unit has passed.
     */
    public void timePassed() { //TODO is it needed???
    }

    /**
     * adding the life indicator to the game.
     *
     * @param game the game
     */
    public void addToGame(GameLevel game) {
        game.addSprite(this);
    }
}