import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Wide easy.
 */
public class Level2 implements LevelInformation {
    private Sprite background;
    private List<Block> blocks;
    private List<Velocity> initialBallVelocities;

    /**
     * Instantiates a new Level 1.
     */
    public Level2() {
        this.background = new Background2();
        this.blocks = new ArrayList<>();
        int i;
        for (i = 0; i < 2; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.CYAN);
            this.blocks.add(block);
        }
        for (; i < 4; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.pink);
            this.blocks.add(block);
        }
        for (; i < 6; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.blue);
            this.blocks.add(block);
        }
        for (; i < 9; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.green);
            this.blocks.add(block);
        }
        for (; i < 11; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.yellow);
            this.blocks.add(block);
        }
        for (; i < 13; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.ORANGE);
            this.blocks.add(block);
        }
        for (; i < 15; ++i) {
            Block block = new Block(new Point(i * 50 + 25, 250), 50, 20);
            block.setBlockHealth(1);
            block.setBlockColor(Color.red);
            this.blocks.add(block);
        }
        this.initialBallVelocities = new ArrayList<>();
        for (int j = -50; j <= 50; j += 10) {
            if (j == 0) {
                continue;
            }
            this.initialBallVelocities.add(Velocity.fromAngleAndSpeed(j, 4));
        }
    }

    /**
     * Number of balls int.
     *
     * @return the int
     */
    @Override
    public int numberOfBalls() {
        return this.initialBallVelocities().size();
    }

    /**
     * Initial ball velocities list.
     *
     * @return the list
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        return this.initialBallVelocities;
    }

    /**
     * Paddle speed int.
     *
     * @return the int
     */
    @Override
    public int paddleSpeed() {
        return 3;
    }

    /**
     * Paddle width int.
     *
     * @return the int
     */
    @Override
    public int paddleWidth() {
        return 650;
    }

    /**
     * Level name string.
     *
     * @return the string
     */
    @Override
    public String levelName() {
        return "Wide Easy";
    }

    /**
     * Gets background.
     *
     * @return the background
     */
    @Override
    public Sprite getBackground() {
        return this.background;
    }

    /**
     * Blocks list.
     *
     * @return the list
     */
    @Override
    public List<Block> blocks() {
        return this.blocks;
    }

    /**
     * Number of blocks to remove int.
     *
     * @return the int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return this.blocks.size();
    }
}
