/**
 * The type Counter.
 */
public class Counter {
    private int counter;

    /**
     * The constructor, initializing counter value to zero.
     */
    public Counter() {
        this.counter = 0;
    }

    /**
     * constructor.
     *
     * @param value - the value for initializing the counter.
     */
    public Counter(int value) {
        this.counter = value;
    }

    /**
     * Increase the counter with given num.
     *
     * @param number the number
     */
// add number to current count.
    void increase(int number) {
        this.counter += number;
    }

    /**
     * Decrease.
     *
     * @param number the number subtract a number from the current counter.
     */
    void decrease(int number) {
        this.counter -= number;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
// get current count.
    public int getValue() {
        return this.counter;
    }

    /**
     * Set value for counter.
     *
     * @param value the value
     */
    public void setValue(int value) {
        this.counter = value;
    }
}