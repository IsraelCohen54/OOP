import biuoop.DrawSurface;
import biuoop.Sleeper;
import java.awt.Color;

/**
 * The type Countdown animation.
 */
// The CountdownAnimation will display the given gameScreen,
// for numOfSeconds seconds, and on top of them it will show
// a countdown from countFrom back to 1, where each number will
// appear on the screen for (numOfSeconds / countFrom) secods, before
// it is replaced with the next one.
public class CountdownAnimation implements Animation {
    private boolean stop; //TODO check if needed
    private double numOfSec;
    private int countFromNum;
    private SpriteCollection gScreen;
    private int chooser = 3;
    private Sleeper sleeper = new Sleeper();

    /**
     * Instantiates a new Countdown animation.
     *
     * @param numOfSeconds the num of seconds
     * @param countFrom    the count from
     * @param gameScreen   the game screen
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen) {
        numOfSec = numOfSeconds;
        countFromNum = countFrom;
        gScreen = gameScreen;
    }

    /**
     * draw 3 2 1 at the start.
     *
     * @param d the surface we draw upon.
     */
    public void doOneFrame(DrawSurface d) {

        if (this.chooser == 3) {
            d.setColor(Color.red);
            d.drawText(10, d.getHeight(), "3...", 400);
        }
        if (this.chooser == 2) {
            d.setColor(Color.ORANGE);
            d.drawText(10, d.getHeight(), "2...", 400);
            this.sleeper.sleepFor((long) numOfSec * 300);
        }
        if (this.chooser == 1) {
            d.setColor(Color.GREEN);
            d.drawText(10, d.getHeight(), "1...", 400);
            this.sleeper.sleepFor((long) numOfSec * 300);
        }
        if (this.chooser == 0) {
            d.setColor(Color.WHITE);
            d.drawText(10, d.getHeight(), "GO", 400);
            this.sleeper.sleepFor((long) numOfSec * 300);
            this.stop = true;
        }
        this.chooser -= 1;
    }

    /**
     * @return this.stop
     */
    public boolean shouldStop() {
        return this.stop;
    }
}