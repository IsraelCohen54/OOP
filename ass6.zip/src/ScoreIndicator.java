import java.awt.Color;

import biuoop.DrawSurface;

/**
 * Class for the core indicator.
 */
public class ScoreIndicator implements Sprite {
    private Counter score;
    private Rectangle rectangle;

    /**
     * Construct the score indicator from the score counter.
     *
     * @param score the score
     */
    public ScoreIndicator(Counter score) {
        this.score = score;
        this.rectangle = new Rectangle(new Point(200, 0), 600, 15);
    }

    /**
     * this method draws the score indicator on given DrawSurface.
     *
     * @param surface the DrawSurface to draw on.
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(Color.LIGHT_GRAY);
        surface.fillRectangle((int) this.rectangle.getUpperLeft().getx(), (int) this.rectangle.getUpperLeft().gety(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
        surface.setColor(Color.BLACK);
        surface.drawText((375), (13), "Score: " + Integer.toString(this.score.getValue()), 13);
    }

    /**
     * Notifying the score indicator that a time unit has passed.
     */
    public void timePassed() { //TODO is it needed???
    }

    /**
     * this method adds the score indicator to a game.
     *
     * @param game the game.
     */
    public void addToGame(GameLevel game) {
        game.addSprite(this);
    }
}