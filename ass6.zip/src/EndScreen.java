import java.awt.Color;

import biuoop.DrawSurface;
//import biuoop.KeyboardSensor;

/**
 * This class represents an end screen object.
 */
public class EndScreen implements Animation {
    private int score;
    // private KeyboardSensor keyboardSensor;
    private boolean win;
    private boolean close;

    /**
     * construct end screen object from a score counter, keyboard sensor,
     * and a boolean win variable.
     *
     * @param score the score counter.
     * @param win   the boolean variable.
     */
    public EndScreen(Counter score/*, KeyboardSensor keyboardSensor*/, boolean win) {
        this.score = score.getValue();
        // this.keyboardSensor = keyboardSensor;
        this.win = win;
        this.close = false;
    }

    /**
     * this method draws each frame of the animation of the end screen.
     * and checks if user pressed SPACE key to close it.
     *
     * @param surface the DrawSurface to draw on.
     */
    public void doOneFrame(DrawSurface surface) {
        surface.setColor(Color.decode("#990000"));
        surface.fillRectangle(0, 0, surface.getWidth(), surface.getHeight());
        surface.setColor(Color.BLACK);
        if (win) {
            surface.drawText(210, 200, "You Won", 100);
            surface.setColor(Color.decode("#ffcb05"));
            surface.drawText(214, 196, "You Won", 100);
        } else {
            surface.drawText(210, 200, "You Lost", 100);
            surface.setColor(Color.decode("#ffcb05"));
            surface.drawText(214, 196, "You Lost", 100);
        }
        surface.setColor(Color.BLACK);
        surface.drawText(250, 350, "Press space to continue", 25);
        surface.setColor(Color.WHITE);
        surface.drawText(50, 580, "Final score: " + this.score, 15);
        /*if (this.keyboardSensor.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.close = true;
        }*/
    }
    /**
     * this method return true if
     * the screen has to be closed, false otherwise.
     *
     * @return true if the screen has to be closed.
     * false otherwise.
     */
    public boolean shouldStop() {
        return this.close;
    }
}