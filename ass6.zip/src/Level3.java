import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Green 3.
 */
public class Level3 implements LevelInformation {
    private Sprite background;
    private List<Block> blocks;
    private List<Velocity> initialBallVelocities;

    /**
     * Instantiates a new Level 3.
     */
    public Level3() {
        this.background = new Background3();
        this.blocks = new ArrayList<Block>();
        for (int i = 0; i < 10; ++i) {
            Block b = new Block(new Point(725 - i * 50, 140), 50, 20);
            b.setBlockHealth(1);
            b.setBlockColor(Color.GRAY);
            this.blocks.add(b);
        }
        for (int i = 0; i < 9; ++i) {
            Block b = new Block(new Point(725 - i * 50, 160), 50, 20);
            b.setBlockHealth(1);
            b.setBlockColor(Color.RED);
            this.blocks.add(b);
        }
        for (int i = 0; i < 8; ++i) {
            Block b = new Block(new Point(725 - i * 50, 180), 50, 20);
            b.setBlockHealth(1);
            b.setBlockColor(Color.YELLOW);
            this.blocks.add(b);
        }
        for (int i = 0; i < 7; ++i) {
            Block b = new Block(new Point(725 - i * 50, 200), 50, 20);
            b.setBlockHealth(1);
            b.setBlockColor(Color.BLUE);
            this.blocks.add(b);
        }
        for (int i = 0; i < 6; ++i) {
            Block b = new Block(new Point(725 - i * 50, 220), 50, 20);
            b.setBlockHealth(1);
            b.setBlockColor(Color.WHITE);
            this.blocks.add(b);
        }
        this.initialBallVelocities = new ArrayList<>();
        this.initialBallVelocities.add(new Velocity(3, -3));
        this.initialBallVelocities.add(new Velocity(-3, -3));
    }

    /**
     * Number of balls int.
     *
     * @return the int
     */
    @Override
    public int numberOfBalls() {
        return this.initialBallVelocities.size();
    }

    /**
     * Initial ball velocities list.
     *
     * @return the list
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        return this.initialBallVelocities;
    }

    /**
     * Paddle speed int.
     *
     * @return the int
     */
    @Override
    public int paddleSpeed() {
        return 6;
    }

    /**
     * Paddle width int.
     *
     * @return the int
     */
    @Override
    public int paddleWidth() {
        return 50;
    }

    /**
     * Level name string.
     *
     * @return the string
     */
    @Override
    public String levelName() {
        return "Green 3";
    }

    /**
     * Gets background.
     *
     * @return the background
     */
    @Override
    public Sprite getBackground() {
        return this.background;
    }

    /**
     * Blocks list.
     *
     * @return the list
     */
    @Override
    public List<Block> blocks() {
        return this.blocks;
    }

    /**
     * Number of blocks to remove int.
     *
     * @return the int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return this.blocks.size();
    }
}
